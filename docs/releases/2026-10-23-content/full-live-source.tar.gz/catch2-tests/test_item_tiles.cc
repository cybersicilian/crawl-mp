#include "catch_amalgamated.hpp"
#include "AppHdr.h"

#ifdef USE_TILE
#include "artefact.h"
#include "invent.h"
#include "item-prop.h"
#include "items.h"
#include "makeitem.h"
#include "player.h"
#include "random.h"
#include "rltiles/tiledef-main.h"
#include "test_player_fixture.h"
#include "tilepick.h"

TEST_CASE_METHOD(MockPlayerYouTestsFixture,
                 "Identifying an item preserves its inventory sprite",
                 "[item-tiles]")
{
    rng::generator inspection(rng::UI);
    for (const auto base : {OBJ_POTIONS, OBJ_SCROLLS, OBJ_JEWELLERY,
                            OBJ_WANDS, OBJ_STAVES})
    {
        for (const int subtype : all_item_subtypes(base))
        {
            if (base == OBJ_JEWELLERY && subtype >= NUM_RINGS
                && subtype < AMU_FIRST_AMULET)
            {
                continue;
            }
            for (const bool type_known : {false, true})
            {
                CAPTURE(static_cast<int>(base), subtype, type_known);
                you.type_ids.init(false);
                item_def item;
                item.base_type = base;
                item.sub_type = subtype;
                item.quantity = 1;
                item_colour(item);
                const tileidx_t appearance = tileidx_item(item);
                vector<tile_def> unknown;
                REQUIRE(get_tiles_for_item(item, unknown, false));
                REQUIRE(unknown.size() == 1);
                REQUIRE(unknown[0].tile == appearance);

                if (type_known)
                    you.type_ids[base][subtype] = true;
                else
                    item.flags |= ISFLAG_IDENTIFIED;
                REQUIRE(item.is_identified());
                vector<tile_def> layers;
                REQUIRE(get_tiles_for_item(item, layers, false));
                REQUIRE(layers.size() >= 2);
                CHECK(layers[0].tile == appearance);
                CHECK(layers[1].tile == tileidx_item(item));
            }
        }
    }
}

TEST_CASE_METHOD(MockPlayerYouTestsFixture,
                 "Catalogue labels still hide unknown appearances",
                 "[item-tiles]")
{
    you.type_ids.init(false);
    CHECK(tileidx_known_base_item(TILE_POT_HEAL_WOUNDS) == TILE_UNSEEN_POTION);
    CHECK(tileidx_known_base_item(TILE_RING_SLAYING) == TILE_UNSEEN_RING);
    CHECK(tileidx_known_base_item(TILE_AMU_GUARDIAN_SPIRIT) == TILE_UNSEEN_AMULET);
}

TEST_CASE_METHOD(MockPlayerYouTestsFixture,
                 "Random artefacts keep their unique inventory sprite",
                 "[item-tiles]")
{
    rng::generator inspection(rng::UI);
    for (const auto base : {OBJ_JEWELLERY, OBJ_STAVES})
    {
        item_def item;
        item.base_type = base;
        item.sub_type = base == OBJ_JEWELLERY ? RING_PROTECTION : STAFF_FIRE;
        item.quantity = 1;
        item_colour(item);
        REQUIRE(make_item_randart(item, true));
        const tileidx_t appearance = tileidx_item(item);
        item.flags |= ISFLAG_IDENTIFIED;
        vector<tile_def> layers;
        REQUIRE(get_tiles_for_item(item, layers, false));
        CHECK(layers[0].tile == appearance);
    }
}
#endif
