util/levcomp.tab.o: util/levcomp.tab.cc AppHdr.h platform.h macros.h \
 libunix.h debug-defines.h tag-version.h debug.h externs.h bitary.h \
 defines.h description-level-type.h dungeon-feature-type.h enum.h \
 spell-type.h branch-type.h fixedarray.h fixedvector.h kill-category.h \
 killer-type.h map-marker-type.h menu-type.h object-class-type.h \
 pattern.h skill-type.h shop-type.h cloud-type.h store.h tags.h \
 coord-def.h level-id.h package.h rltiles/tiledef_defines.h tile-flags.h \
 item-def.h item-status-flag-type.h monster-type.h ray.h geom2d.h tiles.h \
 libconsole.h end.h hiscores.h god-type.h json-wrapper.h json.h \
 score-format-type.h game-exit-type.h ouch.h beam.h ac-type.h beam-type.h \
 enchant-type.h mon-ai-action.h mon-attitude-type.h random.h hash.h \
 rng-type.h pcg.h spl-cast.h evocation.h zap-type.h kill-method-type.h \
 l-defs.h mapdef.h dlua.h clua.h maybe-bool.h fprop.h makeitem.h \
 item-prop-enum.h spl-util.h mon-info.h mon-util.h gender-type.h \
 los-type.h mon-dam-level-type.h mon-enum.h mon-flags.h mon-inv-type.h \
 player.h actor.h artefact-prop-type.h caught-type.h conduct-type.h \
 constrict-type.h energy-use-type.h mon-holy-type.h movement-type.h \
 random-var.h pronoun-type.h size-part-type.h size-type.h stat-type.h \
 attribute-type.h bane-type.h book-type.h caction-type.h daction-type.h \
 duration-type.h flush-reason-type.h game-chapter.h kills.h \
 kill-dump-options-type.h mutation-type.h piety-info.h place-info.h \
 player-equip.h art-enum.h artefact.h unique-item-status-type.h \
 equipment-slot.h transformation.h quiver.h ability-type.h command-type.h \
 format.h skill-menu-state.h species.h job-type.h species-def.h \
 species-type.h undead-state-type.h timed-effect-type.h uncancel.h \
 uncancellable-type.h unique-creature-list-type.h options.h \
 activity-interrupt-type.h char-set-type.h confirm-prompt-type.h \
 easy-confirm-type.h explore-greedy-options.h explore-stop-options.h \
 feature.h dungeon-char-type.h map-feature.h show.h fixedp.h flang-t.h \
 lang-t.h level-gen-type.h longwalk-range-mode.h mpr.h newgame-def.h \
 game-type.h potion-type.h rc-line-type.h screen-mode.h \
 skill-focus-mode.h slot-select-mode.h tag-pref.h \
 travel-open-doors-type.h wizard-option-type.h matrix.h mon-ench.h \
 mon-aura.h travel-defs.h maps.h unwind.h stringutil.h config.h libutil.h \
 util/levcomp.tab.h
